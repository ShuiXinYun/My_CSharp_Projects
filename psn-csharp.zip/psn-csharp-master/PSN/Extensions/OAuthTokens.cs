﻿namespace PSN
{
    public class OAuthTokens
    {
        public string Authorization { get; set; }
        public string Refresh { get; set; }
    }
}